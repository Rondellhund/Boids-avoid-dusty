# Boids avoid v1

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rondellhund-Rondellhund/pen/vYbRmWz](https://codepen.io/Rondellhund-Rondellhund/pen/vYbRmWz).

